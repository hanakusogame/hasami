(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.aez_bundle_main = f()}})(function(){var define,module,exports;return (function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";
var ActionType;
(function (ActionType) {
    ActionType[ActionType["Wait"] = 0] = "Wait";
    ActionType[ActionType["Call"] = 1] = "Call";
    ActionType[ActionType["TweenTo"] = 2] = "TweenTo";
    ActionType[ActionType["TweenBy"] = 3] = "TweenBy";
    ActionType[ActionType["TweenByMult"] = 4] = "TweenByMult";
    ActionType[ActionType["Cue"] = 5] = "Cue";
    ActionType[ActionType["Every"] = 6] = "Every";
})(ActionType || (ActionType = {}));
module.exports = ActionType;

},{}],2:[function(require,module,exports){
"use strict";
/**
 * Easing関数群。
 * 参考: http://gizma.com/easing/
 */
var Easing;
(function (Easing) {
    /**
     * 入力値をlinearした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function linear(t, b, c, d) {
        return c * t / d + b;
    }
    Easing.linear = linear;
    /**
     * 入力値をeaseInQuadした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInQuad(t, b, c, d) {
        t /= d;
        return c * t * t + b;
    }
    Easing.easeInQuad = easeInQuad;
    /**
     * 入力値をeaseOutQuadした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeOutQuad(t, b, c, d) {
        t /= d;
        return -c * t * (t - 2) + b;
    }
    Easing.easeOutQuad = easeOutQuad;
    /**
     * 入力値をeaseInOutQuadした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInOutQuad(t, b, c, d) {
        t /= d / 2;
        if (t < 1)
            return c / 2 * t * t + b;
        --t;
        return -c / 2 * (t * (t - 2) - 1) + b;
    }
    Easing.easeInOutQuad = easeInOutQuad;
    /**
     * 入力値をeaseInQubicした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInCubic(t, b, c, d) {
        t /= d;
        return c * t * t * t + b;
    }
    Easing.easeInCubic = easeInCubic;
    /**
     * @deprecated この関数は非推奨機能である。代わりに `easeInCubic` を用いるべきである。
     */
    Easing.easeInQubic = easeInCubic;
    /**
     * 入力値をeaseOutQubicした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeOutCubic(t, b, c, d) {
        t /= d;
        --t;
        return c * (t * t * t + 1) + b;
    }
    Easing.easeOutCubic = easeOutCubic;
    /**
     * @deprecated この関数は非推奨機能である。代わりに `easeOutCubic` を用いるべきである。
     */
    Easing.easeOutQubic = easeOutCubic;
    /**
     * 入力値をeaseInOutQubicした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInOutCubic(t, b, c, d) {
        t /= d / 2;
        if (t < 1)
            return c / 2 * t * t * t + b;
        t -= 2;
        return c / 2 * (t * t * t + 2) + b;
    }
    Easing.easeInOutCubic = easeInOutCubic;
    /**
     * @deprecated この関数は非推奨機能である。代わりに `easeInOutCubic` を用いるべきである。
     */
    Easing.easeInOutQubic = easeInOutCubic;
    /**
     * 入力値をeaseInQuartした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInQuart(t, b, c, d) {
        t /= d;
        return c * t * t * t * t + b;
    }
    Easing.easeInQuart = easeInQuart;
    /**
     * 入力値をeaseOutQuartした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeOutQuart(t, b, c, d) {
        t /= d;
        --t;
        return -c * (t * t * t * t - 1) + b;
    }
    Easing.easeOutQuart = easeOutQuart;
    /**
     * 入力値をeaseInQuintした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInQuint(t, b, c, d) {
        t /= d;
        return c * t * t * t * t * t + b;
    }
    Easing.easeInQuint = easeInQuint;
    /**
     * 入力値をeaseOutQuintした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeOutQuint(t, b, c, d) {
        t /= d;
        --t;
        return c * (t * t * t * t * t + 1) + b;
    }
    Easing.easeOutQuint = easeOutQuint;
    /**
     * 入力値をeaseInOutQuintした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInOutQuint(t, b, c, d) {
        t /= d / 2;
        if (t < 1)
            return c / 2 * t * t * t * t * t + b;
        t -= 2;
        return c / 2 * (t * t * t * t * t + 2) + b;
    }
    Easing.easeInOutQuint = easeInOutQuint;
    /**
     * 入力値をeaseInSineした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInSine(t, b, c, d) {
        return -c * Math.cos(t / d * (Math.PI / 2)) + c + b;
    }
    Easing.easeInSine = easeInSine;
    /**
     * 入力値をeaseOutSineした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeOutSine(t, b, c, d) {
        return c * Math.sin(t / d * (Math.PI / 2)) + b;
    }
    Easing.easeOutSine = easeOutSine;
    /**
     * 入力値をeaseInOutSineした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInOutSine(t, b, c, d) {
        return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
    }
    Easing.easeInOutSine = easeInOutSine;
    /**
     * 入力値をeaseInExpoした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInExpo(t, b, c, d) {
        return c * Math.pow(2, 10 * (t / d - 1)) + b;
    }
    Easing.easeInExpo = easeInExpo;
    /**
     * 入力値をeaseInOutExpoした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInOutExpo(t, b, c, d) {
        t /= d / 2;
        if (t < 1)
            return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
        --t;
        return c / 2 * (-Math.pow(2, -10 * t) + 2) + b;
    }
    Easing.easeInOutExpo = easeInOutExpo;
    /**
     * 入力値をeaseInCircした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInCirc(t, b, c, d) {
        t /= d;
        return -c * (Math.sqrt(1 - t * t) - 1) + b;
    }
    Easing.easeInCirc = easeInCirc;
    /**
     * 入力値をeaseOutCircした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeOutCirc(t, b, c, d) {
        t /= d;
        --t;
        return c * Math.sqrt(1 - t * t) + b;
    }
    Easing.easeOutCirc = easeOutCirc;
    /**
     * 入力値をeaseInOutCircした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInOutCirc(t, b, c, d) {
        t /= d / 2;
        if (t < 1)
            return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
        t -= 2;
        return c / 2 * (Math.sqrt(1 - t * t) + 1) + b;
    }
    Easing.easeInOutCirc = easeInOutCirc;
})(Easing || (Easing = {}));
module.exports = Easing;

},{}],3:[function(require,module,exports){
"use strict";
var Tween = require("./Tween");
/**
 * タイムライン機能を提供するクラス。
 */
var Timeline = /** @class */ (function () {
    /**
     * Timelineを生成する。
     * @param scene タイムラインを実行する `Scene`
     */
    function Timeline(scene) {
        this._scene = scene;
        this._tweens = [];
        this._fps = this._scene.game.fps;
        this.paused = false;
        scene.update.add(this._handler, this);
    }
    /**
     * Timelineに紐付いたTweenを生成する。
     * @param target タイムライン処理の対象にするオブジェクト
     * @param option Tweenの生成オプション
     */
    Timeline.prototype.create = function (target, option) {
        var t = new Tween(target, option);
        this._tweens.push(t);
        return t;
    };
    /**
     * Timelineに紐付いたTweenを削除する。
     * @param tween 削除するTween。
     */
    Timeline.prototype.remove = function (tween) {
        var index = this._tweens.indexOf(tween);
        if (index < 0) {
            return;
        }
        this._tweens.splice(index, 1);
    };
    /**
     * Timelineに紐付いた全Tweenの紐付けを解除する。
     */
    Timeline.prototype.clear = function () {
        this._tweens.length = 0;
    };
    /**
     * このTimelineを破棄する。
     */
    Timeline.prototype.destroy = function () {
        this._tweens.length = 0;
        if (!this._scene.destroyed()) {
            this._scene.update.remove(this._handler, this);
        }
        this._scene = undefined;
    };
    /**
     * このTimelineが破棄済みであるかを返す。
     */
    Timeline.prototype.destroyed = function () {
        return this._scene === undefined;
    };
    Timeline.prototype._handler = function () {
        if (this._tweens.length === 0 || this.paused) {
            return;
        }
        var tmp = [];
        for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];
            if (!tween.destroyed()) {
                tween._fire(1000 / this._fps);
                tmp.push(tween);
            }
        }
        this._tweens = tmp;
    };
    return Timeline;
}());
module.exports = Timeline;

},{"./Tween":4}],4:[function(require,module,exports){
"use strict";
var Easing = require("./Easing");
var ActionType = require("./ActionType");
/**
 * オブジェクトの状態を変化させるアクションを定義するクラス。
 * 本クラスのインスタンス生成には`Timeline#create()`を利用する。
 */
var Tween = /** @class */ (function () {
    /**
     * Tweenを生成する。
     * @param target 対象となるオブジェクト
     * @param option オプション
     */
    function Tween(target, option) {
        this._target = target;
        this._stepIndex = 0;
        this._loop = !!option && !!option.loop;
        this._modifiedHandler = option && option.modified ? option.modified : undefined;
        this._destroyedHandler = option && option.destroyed ? option.destroyed : undefined;
        this._steps = [];
        this._lastStep = undefined;
        this._pararel = false;
        this.paused = false;
    }
    /**
     * オブジェクトの状態を変化させるアクションを追加する。
     * @param props 変化内容
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.to = function (props, duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: ActionType.TweenTo,
            initialized: false
        };
        this._push(action);
        return this;
    };
    /**
     * オブジェクトの状態を変化させるアクションを追加する。
     * 変化内容はアクション開始時を基準とした相対値で指定する。
     * @param props 変化内容
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     * @param multiply `true`を指定すると`props`の値をアクション開始時の値に掛け合わせた値が終了値となる（指定しない場合は`false`）
     */
    Tween.prototype.by = function (props, duration, easing, multiply) {
        if (easing === void 0) { easing = Easing.linear; }
        if (multiply === void 0) { multiply = false; }
        var type = multiply ? ActionType.TweenByMult : ActionType.TweenBy;
        var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: type,
            initialized: false
        };
        this._push(action);
        return this;
    };
    /**
     * 次に追加されるアクションを、このメソッド呼び出しの直前に追加されたアクションと並列に実行させる。
     * `Tween#con()`で並列実行を指定されたアクションが全て終了後、次の並列実行を指定されていないアクションを実行する。
     */
    Tween.prototype.con = function () {
        this._pararel = true;
        return this;
    };
    /**
     * オブジェクトの変化を停止するアクションを追加する。
     * @param duration 停止する時間（ミリ秒）
     */
    Tween.prototype.wait = function (duration) {
        var action = {
            duration: duration,
            type: ActionType.Wait,
            initialized: false
        };
        this._push(action);
        return this;
    };
    /**
     * 関数を即座に実行するアクションを追加する。
     * @param func 実行する関数
     */
    Tween.prototype.call = function (func) {
        var action = {
            func: func,
            type: ActionType.Call,
            duration: 0,
            initialized: false
        };
        this._push(action);
        return this;
    };
    /**
     * 一時停止するアクションを追加する。
     * 内部的には`Tween#call()`で`Tween#paused`に`true`をセットしている。
     */
    Tween.prototype.pause = function () {
        var _this = this;
        return this.call(function () {
            _this.paused = true;
        });
    };
    /**
     * 待機時間をキーとして実行したい関数を複数指定する。
     * @param actions 待機時間をキーとして実行したい関数を値としたオブジェクト
     */
    Tween.prototype.cue = function (funcs) {
        var keys = Object.keys(funcs);
        keys.sort(function (a, b) {
            return Number(a) > Number(b) ? 1 : -1;
        });
        var q = [];
        for (var i = 0; i < keys.length; ++i) {
            q.push({ time: Number(keys[i]), func: funcs[keys[i]] });
        }
        var action = {
            type: ActionType.Cue,
            duration: Number(keys[keys.length - 1]),
            cue: q,
            initialized: false
        };
        this._push(action);
        return this;
    };
    /**
     * 指定した時間を経過するまで毎フレーム指定した関数を呼び出すアクションを追加する。
     * @param func 毎フレーム呼び出される関数。第一引数は経過時間、第二引数はEasingした結果の変化量（0-1）となる。
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.every = function (func, duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        var action = {
            func: func,
            type: ActionType.Every,
            easing: easing,
            duration: duration,
            initialized: false
        };
        this._push(action);
        return this;
    };
    /**
     * ターゲットをフェードインさせるアクションを追加する。
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.fadeIn = function (duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        return this.to({ opacity: 1 }, duration, easing);
    };
    /**
     * ターゲットをフェードアウトさせるアクションを追加する。
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.fadeOut = function (duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        return this.to({ opacity: 0 }, duration, easing);
    };
    /**
     * ターゲットを指定した座標に移動するアクションを追加する。
     * @param x x座標
     * @param y y座標
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.moveTo = function (x, y, duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        return this.to({ x: x, y: y }, duration, easing);
    };
    /**
     * ターゲットを指定した相対座標に移動するアクションを追加する。相対座標の基準値はアクション開始時の座標となる。
     * @param x x座標
     * @param y y座標
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.moveBy = function (x, y, duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        return this.by({ x: x, y: y }, duration, easing);
    };
    /**
     * ターゲットのX座標を指定した座標に移動するアクションを追加する。
     * @param x x座標
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.moveX = function (x, duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        return this.to({ x: x }, duration, easing);
    };
    /**
     * ターゲットのY座標を指定した座標に移動するアクションを追加する。
     * @param y y座標
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.moveY = function (y, duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        return this.to({ y: y }, duration, easing);
    };
    /**
     * ターゲットを指定した角度に回転するアクションを追加する。
     * @param angle 角度
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.rotateTo = function (angle, duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        return this.to({ angle: angle }, duration, easing);
    };
    /**
     * ターゲットをアクション開始時の角度を基準とした相対角度に回転するアクションを追加する。
     * @param angle 角度
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.rotateBy = function (angle, duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        return this.by({ angle: angle }, duration, easing);
    };
    /**
     * ターゲットを指定した倍率に拡縮するアクションを追加する。
     * @param scaleX X方向の倍率
     * @param scaleY Y方向の倍率
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.scaleTo = function (scaleX, scaleY, duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        return this.to({ scaleX: scaleX, scaleY: scaleY }, duration, easing);
    };
    /**
     * ターゲットのアクション開始時の倍率に指定した倍率を掛け合わせた倍率に拡縮するアクションを追加する。
     * @param scaleX X方向の倍率
     * @param scaleY Y方向の倍率
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.scaleBy = function (scaleX, scaleY, duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        return this.by({ scaleX: scaleX, scaleY: scaleY }, duration, easing, true);
    };
    /**
     * Tweenが破棄されたかどうかを返す。
     * `_target`が破棄された場合又は、全アクションの実行が終了した場合に`true`を返す。
     */
    Tween.prototype.destroyed = function () {
        var ret = false;
        if (this._destroyedHandler) {
            ret = this._destroyedHandler.call(this._target);
        }
        if (!ret) {
            ret = this._stepIndex >= this._steps.length && !this._loop;
        }
        return ret;
    };
    /**
     * アニメーションを実行する。
     * @param delta 前フレームからの経過時間
     */
    Tween.prototype._fire = function (delta) {
        if (this._steps.length === 0 || this.destroyed() || this.paused) {
            return;
        }
        if (this._stepIndex >= this._steps.length) {
            if (this._loop) {
                this._stepIndex = 0;
            }
            else {
                return;
            }
        }
        var actions = this._steps[this._stepIndex];
        var remained = false;
        for (var i = 0; i < actions.length; ++i) {
            var action = actions[i];
            if (!action.initialized) {
                this._initAction(action);
            }
            if (action.finished) {
                continue;
            }
            action.elapsed += delta;
            switch (action.type) {
                case ActionType.Call:
                    action.func.call(this._target);
                    break;
                case ActionType.Every:
                    var progress = action.easing(action.elapsed, 0, 1, action.duration);
                    if (progress > 1) {
                        progress = 1;
                    }
                    action.func.call(this._target, action.elapsed, progress);
                    break;
                case ActionType.TweenTo:
                case ActionType.TweenBy:
                case ActionType.TweenByMult:
                    var keys = Object.keys(action.goal);
                    for (var j = 0; j < keys.length; ++j) {
                        var key = keys[j];
                        if (action.elapsed >= action.duration) {
                            this._target[key] = action.goal[key];
                        }
                        else {
                            this._target[key] = action.easing(action.elapsed, action.start[key], action.goal[key] - action.start[key], action.duration);
                        }
                    }
                    break;
                case ActionType.Cue:
                    var cueAction = action.cue[action.cueIndex];
                    if (cueAction !== undefined && action.elapsed >= cueAction.time) {
                        cueAction.func.call(this._target);
                        ++action.cueIndex;
                    }
                    break;
            }
            if (this._modifiedHandler) {
                this._modifiedHandler.call(this._target);
            }
            if (action.elapsed >= action.duration) {
                action.finished = true;
            }
            else {
                remained = true;
            }
        }
        if (!remained) {
            for (var k = 0; k < actions.length; ++k) {
                actions[k].initialized = false;
            }
            ++this._stepIndex;
        }
    };
    /**
     * Tweenの実行状態をシリアライズして返す。
     */
    Tween.prototype.serializeState = function () {
        var tData = {
            _stepIndex: this._stepIndex,
            _steps: []
        };
        for (var i = 0; i < this._steps.length; ++i) {
            tData._steps[i] = [];
            for (var j = 0; j < this._steps[i].length; ++j) {
                tData._steps[i][j] = {
                    input: this._steps[i][j].input,
                    start: this._steps[i][j].start,
                    goal: this._steps[i][j].goal,
                    duration: this._steps[i][j].duration,
                    elapsed: this._steps[i][j].elapsed,
                    type: this._steps[i][j].type,
                    cueIndex: this._steps[i][j].cueIndex,
                    initialized: this._steps[i][j].initialized,
                    finished: this._steps[i][j].finished
                };
            }
        }
        return tData;
    };
    /**
     * Tweenの実行状態を復元する。
     * @param serializedstate 復元に使う情報。
     */
    Tween.prototype.deserializeState = function (serializedState) {
        this._stepIndex = serializedState._stepIndex;
        for (var i = 0; i < serializedState._steps.length; ++i) {
            for (var j = 0; j < serializedState._steps[i].length; ++j) {
                if (!serializedState._steps[i][j] || !this._steps[i][j])
                    continue;
                this._steps[i][j].input = serializedState._steps[i][j].input;
                this._steps[i][j].start = serializedState._steps[i][j].start;
                this._steps[i][j].goal = serializedState._steps[i][j].goal;
                this._steps[i][j].duration = serializedState._steps[i][j].duration;
                this._steps[i][j].elapsed = serializedState._steps[i][j].elapsed;
                this._steps[i][j].type = serializedState._steps[i][j].type;
                this._steps[i][j].cueIndex = serializedState._steps[i][j].cueIndex;
                this._steps[i][j].initialized = serializedState._steps[i][j].initialized;
                this._steps[i][j].finished = serializedState._steps[i][j].finished;
            }
        }
    };
    /**
     * `this._pararel`が`false`の場合は新規にステップを作成し、アクションを追加する。
     * `this._pararel`が`true`の場合は最後に作成したステップにアクションを追加する。
     */
    Tween.prototype._push = function (action) {
        if (this._pararel) {
            this._lastStep.push(action);
        }
        else {
            var index = this._steps.push([action]) - 1;
            this._lastStep = this._steps[index];
        }
        this._pararel = false;
    };
    Tween.prototype._initAction = function (action) {
        action.elapsed = 0;
        action.start = {};
        action.goal = {};
        action.cueIndex = 0;
        action.finished = false;
        action.initialized = true;
        if (action.type !== ActionType.TweenTo
            && action.type !== ActionType.TweenBy
            && action.type !== ActionType.TweenByMult) {
            return;
        }
        var keys = Object.keys(action.input);
        for (var i = 0; i < keys.length; ++i) {
            var key = keys[i];
            if (this._target[key] !== undefined) {
                action.start[key] = this._target[key];
                if (action.type === ActionType.TweenTo) {
                    action.goal[key] = action.input[key];
                }
                else if (action.type === ActionType.TweenBy) {
                    action.goal[key] = action.start[key] + action.input[key];
                }
                else if (action.type === ActionType.TweenByMult) {
                    action.goal[key] = action.start[key] * action.input[key];
                }
            }
        }
    };
    return Tween;
}());
module.exports = Tween;

},{"./ActionType":1,"./Easing":2}],5:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Timeline = require("./Timeline");
exports.Tween = require("./Tween");
exports.Easing = require("./Easing");

},{"./Easing":2,"./Timeline":3,"./Tween":4}],6:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Button = /** @class */ (function (_super) {
    __extends(Button, _super);
    function Button(scene, s, x, y, w, h) {
        if (x === void 0) { x = 0; }
        if (y === void 0) { y = 0; }
        if (w === void 0) { w = 100; }
        if (h === void 0) { h = 50; }
        var _this = _super.call(this, {
            scene: scene,
            cssColor: "white",
            width: w,
            height: h,
            x: x,
            y: y,
            touchable: true
        }) || this;
        _this.num = 0;
        _this.chkEnable = function (ev) { return true; };
        _this.pushEvent = function () { };
        if (Button.font == null) {
            Button.font = new g.DynamicFont({
                game: g.game,
                fontFamily: g.FontFamily.Monospace,
                size: 32
            });
        }
        _this.label = new g.Label({
            scene: scene,
            font: Button.font,
            text: s[0],
            fontSize: 24,
            textColor: "black",
            widthAutoAdjust: false,
            textAlign: g.TextAlign.Center,
            width: w
        });
        _this.label.y = (h - _this.label.height) / 2;
        _this.label.modified();
        _this.append(_this.label);
        _this.pointDown.add(function (ev) {
            if (!_this.chkEnable(ev))
                return;
            _this.cssColor = "gray";
            _this.modified();
            if (s.length !== 1) {
                _this.num = (_this.num + 1) % s.length;
                _this.label.text = s[_this.num];
                _this.label.invalidate();
            }
            _this.pushEvent();
        });
        _this.pointUp.add(function () {
            _this.cssColor = "white";
            _this.modified();
        });
        return _this;
    }
    return Button;
}(g.FilledRect));
exports.Button = Button;

},{}],7:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Button_1 = require("./Button");
var Panel_1 = require("./Panel");
var MainScene = /** @class */ (function (_super) {
    __extends(MainScene, _super);
    function MainScene(param) {
        var _this = this;
        param.assetIds = ["koma", "koma2", "win", "help", "img_numbers_n", "test"];
        _this = _super.call(this, param) || this;
        var tl = require("@akashic-extension/akashic-timeline");
        var timeline = new tl.Timeline(_this);
        //配信者のIDを取得
        _this.lastJoinedPlayerId = "";
        g.game.join.add(function (ev) {
            _this.lastJoinedPlayerId = ev.player.id;
        });
        _this.update.add(function () {
        });
        _this.loaded.add(function () {
            /*
            //背景
            const bg = this.createRect(0, 0, 640, 360, "gray");
            this.append(bg);
            */
            var playerIds = ["", ""];
            _this.font = new g.DynamicFont({
                game: g.game,
                fontFamily: g.FontFamily.Monospace,
                size: 15
            });
            var title = _this.createLabel(550, 0, "はさみ将棋", 15);
            title.textColor = "white";
            title.invalidate();
            _this.append(title);
            var help = new g.Sprite({
                scene: _this,
                src: _this.assets["help"],
                x: 490,
                y: 292
            });
            _this.append(help);
            var glyph = JSON.parse(_this.assets["test"].data);
            var numFont = new g.BitmapFont({
                src: _this.assets["img_numbers_n"],
                map: glyph.map,
                defaultGlyphWidth: glyph.width,
                defaultGlyphHeight: glyph.height,
                missingGlyph: glyph.missingGlyph
            });
            var mapLength = 9;
            var mapSize = 72;
            var turn = 0;
            var panels = [];
            var dx = [0, 0, 1, -1];
            var dy = [1, -1, 0, 0];
            var movePoss = [];
            var px = 0;
            var py = 0;
            var scale = 330 / (mapSize * mapLength);
            var stage = new g.E({ scene: _this, x: 5, y: 20, scaleX: scale, scaleY: scale });
            _this.append(stage);
            //勝敗
            var sprState = new g.FrameSprite({
                scene: _this,
                src: _this.assets["win"],
                x: 350,
                y: 10,
                width: 150, height: 150,
                frames: [0, 1]
            });
            _this.append(sprState);
            //スコア
            var scores = [0, 0];
            var sprScores = [];
            var labelScore = [];
            var labelPlayer = [];
            var btnPlayers = [];
            var fontPlayer = new g.DynamicFont({
                game: g.game,
                fontFamily: g.FontFamily.Monospace,
                size: 32
            });
            for (var i = 0; i < 2; i++) {
                var stone = new g.FrameSprite({
                    scene: _this,
                    src: _this.assets["koma2"],
                    x: 360,
                    y: 185 + (i * 60),
                    width: 40, height: 40,
                    frames: [i]
                });
                sprScores.push(stone);
                _this.append(stone);
                labelScore.push(_this.createLabel(410, 190 + (i * 60), "0", 32, numFont));
                _this.append(labelScore[i]);
                var btnPlayer = new Button_1.Button(_this, ["全員", "配信者", "視聴者", "先着"], 480, 185 + (i * 60), 100, 30);
                btnPlayer.label.fontSize = 20;
                btnPlayer.label.invalidate();
                _this.append(btnPlayer);
                btnPlayers.push(btnPlayer);
                btnPlayer.chkEnable = function (ev) {
                    return ev.player.id == _this.lastJoinedPlayerId;
                };
                labelPlayer.push(_this.createLabel(480, 215 + (i * 60), "", 16, fontPlayer));
                labelPlayer[i].textColor = "white";
                _this.append(labelPlayer[i]);
            }
            //リセットボタン
            var btnReset = new Button_1.Button(_this, ["リセット"], 360, 300);
            _this.append(btnReset);
            btnReset.chkEnable = function (ev) {
                return ev.player.id == _this.lastJoinedPlayerId;
            };
            btnReset.pushEvent = function () {
                reset();
            };
            //リセット処理
            var reset = function () {
                sprState.hide();
                for (var y = 1; y < mapLength + 1; y++) {
                    for (var x = 1; x < mapLength + 1; x++) {
                        var panel = panels[y][x];
                        if (y == 1) {
                            panel.setNum(0);
                        }
                        else if (y == mapLength) {
                            panel.setNum(1);
                        }
                        else {
                            panel.setNum(3);
                        }
                        panel.komaNum = -1;
                    }
                }
                for (var i = 0; i < mapLength; i++) {
                    komas[0][i].x = mapSize * i;
                    komas[0][i].y = 0;
                    komas[0][i].show();
                    komas[0][i].modified();
                    komas[1][i].x = mapSize * i;
                    komas[1][i].y = mapSize * (mapLength - 1);
                    komas[1][i].show();
                    komas[1][i].modified();
                    panels[1][i + 1].komaNum = i;
                    panels[mapLength][i + 1].komaNum = i;
                }
                for (var i = 0; i < 2; i++) {
                    scores[i] = 0;
                    labelScore[i].text = "0";
                    labelScore[i].invalidate();
                }
                playerIds = ["", ""];
                for (var i = 0; i < 2; i++) {
                    labelPlayer[i].text = "";
                    labelPlayer[i].invalidate();
                }
                if (cursorNow.parent != null) {
                    cursorNow.remove();
                }
                sprScores[1].append(cursorTeban);
                turn = 1;
            };
            //座標描画
            var numStrs = ["一", "二", "三", "四", "五", "六", "七", "八", "九"];
            for (var i = 0; i < mapLength; i++) {
                var label = _this.createLabel(mapSize * i + 30, -42, "" + (9 - i));
                label.textColor = "white";
                label.invalidate();
                stage.append(label);
                label = _this.createLabel(mapSize * mapLength, mapSize * i + 20, numStrs[i]);
                label.textColor = "white";
                label.invalidate();
                stage.append(label);
            }
            //枠の描画
            for (var i = 0; i < mapLength + 1; i++) {
                stage.append(_this.createRect(mapSize * i - 2, -2, 4, mapSize * mapLength + 4));
                stage.append(_this.createRect(-2, mapSize * i - 2, mapSize * mapLength + 4, 4));
            }
            //手番表示用カーソル
            var cursorTeban = _this.createRect(-12, 14, 12, 12, "red");
            //直近の着手の手番のカーソル
            var cursorNow = _this.createRect(0, 0, mapSize, mapSize, "#ffff0030");
            var _loop_1 = function (y) {
                panels.push([]);
                var _loop_2 = function (x) {
                    var panel = new Panel_1.Panel(_this, mapSize * (x - 1), mapSize * (y - 1), mapSize - 2, mapSize - 2);
                    stage.append(panel);
                    //クリックイベント
                    panel.pointDown.add(function (ev) {
                        if (sprState.visible())
                            return;
                        if (btnPlayers[turn % 2].num == 1 && ev.player.id != _this.lastJoinedPlayerId)
                            return;
                        if (btnPlayers[turn % 2].num == 2 && ev.player.id == _this.lastJoinedPlayerId)
                            return;
                        if (btnPlayers[turn % 2].num == 3 && (ev.player.id != playerIds[turn % 2] && playerIds[turn % 2] != ""))
                            return;
                        if (btnPlayers[turn % 2].num != 3 || (btnPlayers[turn % 2].num == 3 && playerIds[turn % 2] == "")) {
                            playerIds[turn % 2] = ev.player.id;
                            if (ev.player.name != undefined) {
                                labelPlayer[turn % 2].text = ev.player.name;
                                labelPlayer[turn % 2].invalidate();
                            }
                        }
                        if (panel.num == (turn % 2)) {
                            movePoss.forEach(function (e) {
                                panels[e[1]][e[0]].setNum(3);
                            });
                            movePoss.length = 0;
                            for (var i = 0; i < 4; i++) {
                                var xx = x;
                                var yy = y;
                                while (true) {
                                    xx += dx[i];
                                    yy += dy[i];
                                    if (panels[yy][xx].num >= 2) {
                                        panels[yy][xx].setNum(2);
                                        movePoss.push([xx, yy]);
                                    }
                                    else {
                                        break;
                                    }
                                }
                            }
                            px = x;
                            py = y;
                        }
                        if (panel.num == 2) {
                            movePoss.forEach(function (e) {
                                panels[e[1]][e[0]].setNum(3);
                            });
                            movePoss.length = 0;
                            panels[py][px].setNum(3);
                            panels[y][x].setNum(turn % 2);
                            var komaNum = panels[py][px].komaNum;
                            panels[y][x].komaNum = komaNum;
                            panels[py][px].komaNum = -1;
                            var k = komas[turn % 2][komaNum];
                            timeline.create(k, { modified: k.modified, destroyed: k.destroyed })
                                .moveTo(panels[y][x].x, panels[y][x].y, 200);
                            //komas[turn % 2][komaNum].x = panels[y][x].x;
                            //komas[turn % 2][komaNum].y = panels[y][x].y;
                            //komas[turn % 2][komaNum].modified();
                            //挟んだとき
                            var num_1 = 0;
                            var hitChk_1 = function (x, y, dx, dy) {
                                if (panels[y][x].num >= 2 || panels[y][x].num == -1)
                                    return false;
                                if (panels[y][x].num == turn % 2)
                                    return true;
                                if (hitChk_1(x + dx, y + dy, dx, dy)) {
                                    panels[y][x].setNum(3);
                                    var k_1 = komas[(turn + 1) % 2][panels[y][x].komaNum];
                                    timeline.create(k_1, { modified: k_1.modified, destroyed: k_1.destroyed })
                                        .wait(300).call(function () { return k_1.hide(); });
                                    //komas[(turn + 1) % 2][panels[y][x].komaNum].hide();
                                    num_1++;
                                    return true;
                                }
                                return false;
                            };
                            for (var i = 0; i < 4; i++) {
                                hitChk_1(x + dx[i], y + dy[i], dx[i], dy[i]);
                            }
                            //囲ったとき
                            var test_1 = [];
                            var hitChk2_1 = function (x, y) {
                                if (panels[y][x].num >= 2)
                                    return false;
                                if (panels[y][x].num == turn % 2 || panels[y][x].num == -1)
                                    return true;
                                panels[y][x].num = turn % 2;
                                var flg = true;
                                for (var i = 0; i < 4; i++) {
                                    if (!hitChk2_1(x + dx[i], y + dy[i])) {
                                        flg = false;
                                    }
                                }
                                panels[y][x].num = (turn + 1) % 2;
                                if (flg) {
                                    test_1.push([x, y]);
                                    return true;
                                }
                                return false;
                            };
                            for (var i = 0; i < 4; i++) {
                                test_1.length = 0;
                                if (hitChk2_1(x + dx[i], y + dy[i])) {
                                    test_1.forEach(function (e) {
                                        panels[e[1]][e[0]].setNum(3);
                                        var k = komas[(turn + 1) % 2][panels[e[1]][e[0]].komaNum];
                                        timeline.create(k, { modified: k.modified, destroyed: k.destroyed })
                                            .wait(300).call(function () { return k.hide(); });
                                    });
                                    num_1 += test_1.length;
                                }
                            }
                            if (num_1 != 0) {
                                var i = turn % 2;
                                scores[i] += num_1;
                                labelScore[i].text = "" + scores[i];
                                labelScore[i].invalidate();
                                if (scores[i] >= 3) {
                                    sprState.show();
                                    sprState.frameNumber = i;
                                    sprState.modified();
                                }
                            }
                            komas[turn % 2][panels[y][x].komaNum].append(cursorNow);
                            turn++;
                            sprScores[turn % 2].append(cursorTeban);
                        }
                    });
                    if (x == 0 || y == 0 || x == mapLength + 1 || y == mapLength + 1) {
                        panel.num = -1;
                        panel.hide();
                    }
                    panels[y].push(panel);
                };
                for (var x = 0; x < mapLength + 2; x++) {
                    _loop_2(x);
                }
            };
            for (var y = 0; y < mapLength + 2; y++) {
                _loop_1(y);
            }
            var komas = [];
            komas.push([]);
            for (var i = 0; i < mapLength; i++) {
                var koma = new g.FrameSprite({
                    scene: _this,
                    src: _this.assets["koma"],
                    width: 72,
                    height: 72,
                    frames: [0]
                });
                stage.append(koma);
                komas[0].push(koma);
                panels[1][i + 1].komaNum = i;
            }
            komas.push([]);
            for (var i = 0; i < mapLength; i++) {
                var koma = new g.FrameSprite({
                    scene: _this,
                    src: _this.assets["koma"],
                    width: 72,
                    height: 72,
                    frames: [1],
                });
                stage.append(koma);
                komas[1].push(koma);
                panels[mapLength][i + 1].komaNum = i;
            }
            reset();
        });
        return _this;
    }
    MainScene.prototype.createLabel = function (x, y, s, size, f) {
        if (size === void 0) { size = 32; }
        if (f === void 0) { f = this.font; }
        return new g.Label({
            scene: this,
            x: x, y: y,
            text: s,
            fontSize: size,
            font: f
        });
    };
    MainScene.prototype.createRect = function (x, y, w, h, c) {
        if (c === void 0) { c = "white"; }
        return new g.FilledRect({
            scene: this,
            x: x, y: y,
            width: w, height: h,
            cssColor: c,
        });
    };
    return MainScene;
}(g.Scene));
exports.MainScene = MainScene;

},{"./Button":6,"./Panel":8,"@akashic-extension/akashic-timeline":5}],8:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Panel = /** @class */ (function (_super) {
    __extends(Panel, _super);
    function Panel(scene, x, y, w, h) {
        var _this = _super.call(this, {
            scene: scene,
            x: x, y: y,
            width: w, height: h,
            cssColor: "yellow",
            touchable: true,
            opacity: 0
        }) || this;
        _this.num = 3;
        _this.komaNum = -1;
        _this.colorStrs = ["green", "blue", "yellow", "white"];
        return _this;
    }
    Panel.prototype.setNum = function (i) {
        this.num = i;
        //his.cssColor = this.colorStrs[i];
        //this.modified();
        if (i == 2) {
            this.opacity = 0.2;
        }
        else {
            this.opacity = 0;
        }
        this.modified();
    };
    return Panel;
}(g.FilledRect));
exports.Panel = Panel;

},{}],9:[function(require,module,exports){
"use strict";
var MainScene_1 = require("./MainScene");
function main(param) {
    //const DEBUG_MODE: boolean = true;
    var scene = new MainScene_1.MainScene({ game: g.game });
    g.game.pushScene(scene);
}
module.exports = main;

},{"./MainScene":7}]},{},[9])(9)
});
